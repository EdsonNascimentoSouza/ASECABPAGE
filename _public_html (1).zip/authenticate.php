<?php
// Habilitar a exibição de erros para debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Conexão com o banco de dados
include 'conexao.php'; // O arquivo conexao.php já cria a conexão $conn

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // Proteção contra SQL Injection
    $user = $conn->real_escape_string($user);

    // Busca o usuário no banco
    $sql = "SELECT * FROM users WHERE username='$user'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // Verifica se a senha fornecida corresponde ao hash armazenado no banco
        if (isset($row['password']) && password_verify($pass, $row['password'])) {
            $_SESSION['username'] = $user;
            header("Location: index.php");
            exit;
        } else {
            // Senha incorreta, enviar erro de volta
            $_SESSION['error_message'] = 'Senha incorreta!';
            header("Location: login.php");
            exit;
        }
    } else {
        // Usuário não encontrado, enviar erro de volta
        $_SESSION['error_message'] = 'Usuário não encontrado!';
        header("Location: login.php");
        exit;
    }
}

$conn->close();
?>
