<?php
// Incluir o arquivo de conexão
include 'conexao.php';

if (isset($_POST['nome'])) {
    $nome = mysqli_real_escape_string($conn, $_POST['nome']);

    // Consultar o banco de dados
    $sql = "SELECT * FROM usuarios WHERE nome LIKE '%$nome%'";
    $result = mysqli_query($conn, $sql);

    // Verificar se encontrou algum usuário
    if (mysqli_num_rows($result) > 0) {
        // Retornar os dados do usuário em formato JSON
        $usuario = mysqli_fetch_assoc($result);
        echo json_encode($usuario);
    } else {
        echo json_encode(null);
    }
}
?>
