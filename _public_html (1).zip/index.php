<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['username'])) {
    // Se não estiver logado, redireciona para a página de login
    header('Location: logout.php');
    exit();
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ASECAB</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .sidebar {
            background-color: #003366;
            color: #fff;
            width: 200px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
            padding-top: 60px;
        }

        .sidebar a {
            display: block;
            padding: 10px 20px;
            text-decoration: none;
            color: #fff;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #ffcc00;
        }

        .container {
            margin-left: 220px;
            padding: 20px;
            width: calc(100% - 220px);
        }

        .container h1 {
            color: #003366;
            text-align: center;
        }

        .form-section {
            display: none;
        }

        .form-section.active {
            display: block;
        }

        h2 {
            color: #003366;
            margin-top: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            margin-bottom: 20px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            margin-bottom: 5px;
            color: #003366;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        input[type="file"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        input[type="submit"] {
            padding: 10px;
            background-color: #ffcc00;
            border: none;
            border-radius: 5px;
            color: #003366;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
            font-size: 14px;
        }

        input[type="submit"]:hover {
            background-color: #ffdd33;
        }

        #menuToggle {
            position: fixed;
            left: 10px;
            top: 10px;
            background-color: #003366;
            color: #fff;
            border: none;
            padding: 10px;
            cursor: pointer;
            z-index: 1000;
        }

        #dashboard {
            margin-top: 20px;
        }

        #dashboard canvas {
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .inicio-image {
            display: block;
            margin: 0 auto 20px auto;
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* Estilo do botão personalizado */
        .custom-button {
            background-color: #FFD700; /* Cor de fundo amarelo */
            border: none;              /* Remover borda */
            color: black;              /* Cor do texto */
            padding: 10px 20px;        /* Espaçamento interno */
            text-align: center;        /* Alinhamento do texto */
            text-decoration: none;     /* Remover underline do link */
            display: inline-block;     /* Exibição em linha */
            font-size: 16px;           /* Tamanho da fonte */
            border-radius: 5px;        /* Bordas arredondadas */
            cursor: pointer;          /* Cursor de ponteiro */
        }
        .custom-button:hover {
            background-color: #FFCC00; /* Cor de fundo ao passar o mouse (tom mais escuro) */
        }
        
        /* Estilo do botão personalizado Cadastro */
.custom-button {
    background-color: #FFD700; /* Cor de fundo amarelo */
    border: none;              /* Remover borda */
    color: black;              /* Cor do texto */
    padding: 10px 20px;        /* Espaçamento interno */
    text-align: center;        /* Alinhamento do texto */
    text-decoration: none;     /* Remover underline do link */
    display: inline-block;     /* Exibição em linha */
    font-size: 16px;           /* Tamanho da fonte */
    border-radius: 5px;        /* Bordas arredondadas */
    cursor: pointer;          /* Cursor de ponteiro */
}

.custom-button:hover {
    background-color: #FFCC00; /* Cor de fundo ao passar o mouse (tom mais escuro) */
}
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <button id="menuToggle">Menu</button>
    <div class="sidebar" id="sidebar">
        <a href="#" onclick="showSection('inicio')">Início</a>
        <a href="#" onclick="showSection('cadastro')">Cadastro</a>
        <a href="#" onclick="showSection('consultar')">Consulta</a>
        <a href="#" onclick="showSection('editar')">Editar</a>
        <a href="cadastro.php">Cadastro de Usuário</a>
        <a href="alterar_senha.php">Alterar Senha</a>
        <a href="excluir_usuario.php">Excluir Usuário</a>
        <a href="logout.php">Sair</a>
    </div>

    <div class="container">
        <h1>Instituto Social ASECAB</h1>

        <!-- Seção Início -->
        <section id="inicio" class="form-section active">
    <h2>Bem-vindo ao CRM Instituto Social ASECAB</h2>
    <p>Nosso objetivo é oferecer assistência a pessoas em situação de vulnerabilidade.</p>
    <img src="imagens/minha-image.jpg" alt="Instituto Social ASECAB" width="300" class="inicio-image">
    <p><strong>QUEM SOMOS:</strong></p>
    <p>O Instituto Social ASECAB nasceu em 2018 com o sonho de proporcionar uma vida melhor nas comunidades, lutar por direitos, em especial os das crianças e adolescentes, gerando oportunidades para que possam crescer e ter um futuro melhor. Atuamos para impactar e transformar a vida desses jovens por meio de acolhimento, educação, arte, saúde, esporte e capacitação profissional. Outro foco do instituto é a proteção e a garantia de direitos da população idosa. Tudo isso movido pela mesma força: o amor ao próximo.</p>

    <p><strong>NOSSA MISSÃO:</strong><br>
    Ser reconhecida como instituição de promoção social e de desenvolvimento integral e harmônico da criança, do adolescente e de proteção ao idoso. Atuar junto às famílias com atendimento multidisciplinar, fortalecendo a função protetiva.</p>

    <p><strong>NOSSA VISÃO:</strong><br>
    Ser um espaço de referência em proteção social, no desenvolvimento de crianças e jovens e de proteção do idoso, dando apoio às famílias visando a harmonia, autonomia e o equilíbrio entre seus membros.</p>

    <p><strong>NOSSOS VALORES:</strong></p>
    <ul>
        <li>TRANSPARÊNCIA</li>
        <li>ÉTICA</li>
        <li>RESPONSABILIDADE SOCIAL</li>
        <li>VALORIZAÇÃO DE PARCERIAS</li>
        <li>RESPEITO PELA DIVERSIDADE</li>
    </ul>

    <img src="imagens/Asset9ASECAB.png" alt="ASECAB Logo" width="200">

    <p><strong>CNPJ:</strong> 31.435.074/0001-84</p>
    <p><strong>Instagram:</strong> @institutosocialasecab</p>
    <p><strong>Email:</strong> asecabbrasil@gmail.com</p>
    
 <a href="https://www.institutosocialasecab.org/" class="custom-button" target="_blank">Acessar o Site</a>



</a>

</section>

        <!-- Seção Cadastro -->
        <section id="cadastro" class="form-section">
            <h2>Cadastro de Beneficiário</h2>
            <form action="cadastro_processar.php" method="POST">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" required><br><br>

                <label for="telefone">Telefone:</label>
                <input type="text" id="telefone" name="telefone" required><br><br>

                <label for="cpf">CPF:</label>
                <input type="text" id="cpf" name="cpf" required><br><br>

                <label for="sexo">Sexo:</label>
                <select id="sexo" name="sexo" required>
                    <option value="Masculino">Masculino</option>
                    <option value="Feminino">Feminino</option>
                    <option value="Outro">Outro</option>
                </select><br><br>

                <label for="idade">Idade:</label>
                <input type="number" id="idade" name="idade" required><br><br>

                <label for="endereco">Endereço:</label>
                <input type="text" id="endereco" name="endereco" required><br><br>

                <label for="cep">CEP:</label>
                <input type="text" id="cep" name="cep" required><br><br>

                <label for="rg">RG:</label>
                <input type="text" id="rg" name="rg" required><br><br>

                <label for="nome_pai">Nome do Pai:</label>
                <input type="text" id="nome_pai" name="nome_pai"><br><br>

                <label for="nome_mae">Nome da Mãe:</label>
                <input type="text" id="nome_mae" name="nome_mae"><br><br>
                
                
                   <h3>Responsável Legal</h3>


                <label for="nome_responsavel_2">Nome:</label>
                <input type="text" id="nome_responsavel_2" name="nome_responsavel_2"><br><br>

                <label for="nascimento_responsavel_2">Data de Nascimento:</label>
                <input type="date" id="nascimento_responsavel_2" name="nascimento_responsavel_2"><br><br>

                <label for="whatsapp_responsavel_2">WhatsApp:</label>
                <input type="text" id="whatsapp_responsavel_2" name="whatsapp_responsavel_2"><br><br>

                <label for="telefone_responsavel_2">Telefone:</label>
                <input type="text" id="telefone_responsavel_2" name="telefone_responsavel_2"><br><br>

                <label for="parentesco_responsavel_2">Grau de Parentesco:</label>
                <input type="text" id="parentesco_responsavel_2" name="parentesco_responsavel_2"><br><br>

                <button type="submit" class="custom-button">Cadastrar</button>

            </form>
        </section>

        <!-- Seção de Consulta -->
<section id="consultar" class="form-section">
    <h2>Buscar Beneficiário </h2>
    <!-- Formulário de Pesquisa -->
    <form id="consultaForm">
        <label for="pesquisa">Pesquisar:</label>
        <input type="text" name="pesquisa" id="pesquisa" required>
        <input type="submit" value="Consultar">
    </form>

<!-- Resultados da consulta, que serão exibidos sem recarregar a página -->
<div id="resultadoConsulta"></div>

<script>
    // Enviar o formulário via AJAX
    document.getElementById('consultaForm').addEventListener('submit', function(event) {
        event.preventDefault();  // Impede o envio tradicional do formulário

        var formData = new FormData(this);
        var xhr = new XMLHttpRequest();

        xhr.open('POST', 'consultar.php', true); // Envia os dados para o script PHP

        xhr.onload = function() {
            if (xhr.status === 200) {
                // Quando a resposta for recebida, exibe os resultados na mesma página
                document.getElementById('resultadoConsulta').innerHTML = xhr.responseText;
            } else {
                // Em caso de erro no envio, mostra uma mensagem no console
                console.error('Erro ao enviar o formulário');
            }
        };

        xhr.send(formData);  // Envia os dados para o PHP via AJAX
    });
</script>


        <!-- Seção Editar -->
        <section id="editar" class="form-section">
            <h2>Editar Funcionário</h2>
            <form action="editar_funcionario.php" method="POST">
                <label for="nome">Nome do Funcionário:</label>
                <input type="text" id="nome" name="nome" required>
                <button type="submit">Consultar</button>
            </form>
        </section>
    </div>

    <script>
        // Função para lidar com a navegação entre seções
        function showSection(sectionId) {
            const sections = document.querySelectorAll('.form-section');
            sections.forEach(section => section.classList.remove('active'));
            document.getElementById(sectionId).classList.add('active');
        }

        // Função para garantir que a seção inicial seja exibida
        document.addEventListener('DOMContentLoaded', function() {
            showSection('inicio'); // Exibe a seção 'inicio' quando a página carregar
        });

        // Funcionalidade do menu toggle (mostrar/ocultar o menu lateral)
        document.getElementById('menuToggle').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.style.display = (sidebar.style.display === 'none') ? 'block' : 'none';
        });

        // Função para a consulta via AJAX
        document.getElementById('consultaForm').addEventListener('submit', function(event) {
            event.preventDefault();
    
            var formData = new FormData(this);
            var xhr = new XMLHttpRequest();
    
            xhr.open('GET', 'consultar_funcionario.php?' + new URLSearchParams(formData).toString(), true);
    
            xhr.onload = function() {
                if (xhr.status >= 200 && xhr.status < 400) {
                    document.getElementById('resultadoConsulta').innerHTML = xhr.responseText;
                } else {
                    console.error('Erro ao consultar funcionário');
                }
            };
    
            xhr.onerror = function() {
                console.error('Erro de conexão');
            };
    
            xhr.send();
        });
    </script>
</body>
</html>

