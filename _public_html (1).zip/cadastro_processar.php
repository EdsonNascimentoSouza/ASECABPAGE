<?php
// Habilitar a exibição de erros para debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
// Incluir o arquivo de conexão
include 'conexao.php';

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obter os dados do formulário com sanitização
    $nome = mysqli_real_escape_string($conn, $_POST['nome']);
    $telefone = mysqli_real_escape_string($conn, $_POST['telefone']);
    $cpf = mysqli_real_escape_string($conn, $_POST['cpf']);
    $sexo = mysqli_real_escape_string($conn, $_POST['sexo']);
    $idade = (int)$_POST['idade'];
    $endereco = mysqli_real_escape_string($conn, $_POST['endereco']);
    $cep = mysqli_real_escape_string($conn, $_POST['cep']);
    $rg = mysqli_real_escape_string($conn, $_POST['rg']);
    $nome_pai = mysqli_real_escape_string($conn, $_POST['nome_pai']);
    $nome_mae = mysqli_real_escape_string($conn, $_POST['nome_mae']);

    // Dados do segundo responsável
    $nome_responsavel_2 = mysqli_real_escape_string($conn, $_POST['nome_responsavel_2']);
    $nascimento_responsavel_2 = mysqli_real_escape_string($conn, $_POST['nascimento_responsavel_2']);
    $whatsapp_responsavel_2 = mysqli_real_escape_string($conn, $_POST['whatsapp_responsavel_2']);
    $telefone_responsavel_2 = mysqli_real_escape_string($conn, $_POST['telefone_responsavel_2']);
    $parentesco_responsavel_2 = mysqli_real_escape_string($conn, $_POST['parentesco_responsavel_2']);

    // Preparar a consulta SQL para inserção
    $sql = "INSERT INTO usuarios (
        nome, telefone, cpf, sexo, idade, endereco, cep, rg, nome_pai, nome_mae,
        nome_responsavel_2, nascimento_responsavel_2, whatsapp_responsavel_2, telefone_responsavel_2, parentesco_responsavel_2
    ) VALUES (
        '$nome', '$telefone', '$cpf', '$sexo', $idade, '$endereco', '$cep', '$rg', '$nome_pai', '$nome_mae',
        '$nome_responsavel_2', '$nascimento_responsavel_2', '$whatsapp_responsavel_2', '$telefone_responsavel_2', '$parentesco_responsavel_2'
    )";

    // Executar a consulta SQL
    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
        exit;
    } else {
        echo "<script>alert('Erro ao realizar cadastro: " . $conn->error . "');</script>";
    }
}

