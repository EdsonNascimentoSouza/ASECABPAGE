<?php
// Conexão com o banco de dados
include 'conexao.php';

// Dados do usuário
$username = 'teste';
$password = 'teste';

// Criptografando a senha
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Inserindo o usuário na tabela
$sql = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";

if ($conn->query($sql) === TRUE) {
    echo "Usuário de teste adicionado com sucesso!";
} else {
    echo "Erro: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
