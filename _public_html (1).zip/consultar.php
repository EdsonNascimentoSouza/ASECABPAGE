<?php
// Incluir a conexão com o banco de dados
include 'conexao.php'; // Certifique-se de que esse arquivo existe e conecta corretamente ao banco

// Habilitar exibição de erros (apenas para desenvolvimento)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Verificar se a pesquisa foi enviada
if (isset($_POST['pesquisa'])) {
    $pesquisa = mysqli_real_escape_string($conn, $_POST['pesquisa']);  

    if (empty($pesquisa)) {
        echo "<p>Por favor, insira um termo de pesquisa.</p>";
    } else {
        $sql = "SELECT * FROM usuarios WHERE nome LIKE '%$pesquisa%' OR cpf LIKE '%$pesquisa%'";
        $resultado = $conn->query($sql);

        if (!$resultado) {
            die("Erro na consulta SQL: " . mysqli_error($conn));
        }

        if ($resultado->num_rows > 0) {
            echo "<div class='resultados'>";
            while ($row = $resultado->fetch_assoc()) {
                echo "<div class='resultado-item' style='border: 1px solid #ccc; padding: 10px; margin-bottom: 10px; border-radius: 8px;'>
                        <h3>{$row['nome']}</h3>
                        <p><strong>Telefone:</strong> {$row['telefone']}</p>
                        <p><strong>CPF:</strong> {$row['cpf']}</p>
                        <p><strong>Sexo:</strong> {$row['sexo']}</p>
                        <p><strong>Idade:</strong> {$row['idade']}</p>
                        <p><strong>Endereço:</strong> {$row['endereco']}</p>
                        <p><strong>CEP:</strong> {$row['cep']}</p>
                        <p><strong>RG:</strong> {$row['rg']}</p>
                        <p><strong>Nome do Pai:</strong> {$row['nome_pai']}</p>
                        <p><strong>Nome da Mãe:</strong> {$row['nome_mae']}</p>";

                // Verifica se os dados do responsável 2 existem
                if (!empty($row['nome_responsavel_2'])) {
                    echo "<hr><h4>Responsável Legal</h4>
                          <p><strong>Nome:</strong> {$row['nome_responsavel_2']}</p>
                          <p><strong>Nascimento:</strong> {$row['nascimento_responsavel_2']}</p>
                          <p><strong>WhatsApp:</strong> {$row['whatsapp_responsavel_2']}</p>
                          <p><strong>Telefone:</strong> {$row['telefone_responsavel_2']}</p>
                          <p><strong>Parentesco:</strong> {$row['parentesco_responsavel_2']}</p>";
                }

                echo "</div>";
            }
            echo "</div>";
        } else {
            echo "<p>Nenhum registro encontrado.</p>";
        }
    }
}
?>
