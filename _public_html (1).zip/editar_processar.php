<?php
// Habilitar a exibição de erros para debug
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

include 'conexao.php'; // Inclua o arquivo de conexão ao banco de dados

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];

    // Consulta para obter os dados do funcionário pelo nome
    $sql = "SELECT * FROM usuarios WHERE nome = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $nome);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $usuarios = $result->fetch_assoc();

        // Mostra o formulário de edição com os dados do funcionário
       echo '<!DOCTYPE html>';
        echo '<html lang="pt-br">';
        echo '<head>';
        echo '<meta charset="UTF-8">';
        echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
        echo '<title>Editar Funcionário</title>';
        echo '<style>';
        echo 'body { font-family: Arial, sans-serif; background-color: #f0f0f0; color: #333; }';
        echo '.form-container { max-width: 600px; margin: 50px auto; padding: 20px; background-color: #fff; border: 1px solid #ccc; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }';
        echo 'h2 { color: #0056b3; text-align: center; }';
        echo 'label { display: block; margin: 10px 0 5px; color: #0056b3; }';
        echo 'input[type="text"], input[type="email"], input[type="number"], textarea, select { width: 100%; padding: 10px; margin: 5px 0 20px; border: 1px solid #ccc; border-radius: 5px; }';
        echo 'button { display: block; width: 100%; padding: 10px; background-color: #ffd700; color: #0056b3; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }';
        echo 'button:hover { background-color: #ffc107; }';
        echo '</style>';
        echo '</head>';
        echo '<body>';
        echo '<div class="form-container">';
        echo '<h2>Editar Funcionário</h2>';
        echo '<form action="salvar_edicao.php" method="POST">';
        echo '<input type="hidden" name="id_funcionario" value="' . $usuarios['id'] . '">';

        echo '<label for="nome">Nome:</label>';
        echo '<input type="text" id="nome" name="nome" value="' . $usuarios['nome'] . '" required>';

        echo '<label for="telefone">Telefone:</label>';
        echo '<input type="text" id="telefone" name="telefone" value="' . $$usuarios['telefone'] . '">';

        echo '<label for="cpf">CPF:</label>';
        echo '<input type="text" id="cpf" name="cpf" value="' . $$usuarios['cpf'] . '">';

        echo '<label for="sexo">Sexo:</label>';
        echo '<select id="sexo" name="sexo" required>';
        echo '<option value="Masculino" ' . (($usuarios['sexo'] == 'Masculino') ? 'selected' : '') . '>Masculino</option>';
        echo '<option value="Feminino" ' . (($usuarios['sexo'] == 'Feminino') ? 'selected' : '') . '>Feminino</option>';
        echo '<option value="Outro" ' . (($usuarios['sexo'] == 'Outro') ? 'selected' : '') . '>Outro</option>';
        echo '</select>';

        echo '<label for="idade">Idade:</label>';
        echo '<input type="number" id="idade" name="idade" value="' . $usuarios['idade'] . '">';

        echo '<label for="endereco">Endereço:</label>';
        echo '<textarea id="endereco" name="endereco">' . $usuarios['endereco'] . '</textarea>';

        echo '<label for="cep">CEP:</label>';
        echo '<input type="text" id="cep" name="cep" value="' . $usuarios['cep'] . '">';

        echo '<label for="rg">RG:</label>';
        echo '<input type="text" id="rg" name="rg" value="' . $usuarios['rg'] . '">';

        echo '<label for="nome_pai">Nome do Pai:</label>';
        echo '<input type="text" id="nome_pai" name="nome_pai" value="' . $usuarios['nome_pai'] . '">';

        echo '<label for="nome_mae">Nome da Mãe:</label>';
        echo '<input type="text" id="nome_mae" name="nome_mae" value="' . $usuarios['nome_mae'] . '">';

        echo '<button type="submit">Salvar</button>';
        echo '</form>';
        echo '</div>';
        echo '</body>';
        echo '</html>';
    } else {
        echo 'Funcionário não encontrado para o nome: ' . htmlspecialchars($nome);
    }

    $stmt->close();
    $conn->close();
}
?>
