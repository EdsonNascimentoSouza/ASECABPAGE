<?php
// Configurações de conexão
$host = "localhost"; // Use 'localhost' ou o IP do servidor de banco de dados
$usuario = "u318244697_asecab"; // Usuário do banco de dados
$senha = "Asecab@2024";         // Senha do banco de dados
$banco = "u318244697_asecab";   // Nome do banco de dados

// Criar conexão
$conn = new mysqli($host, $usuario, $senha, $banco);

// Verificar a conexão
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

echo "";
?>
