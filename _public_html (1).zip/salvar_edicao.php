<?php
include 'conexao.php'; // Inclua o arquivo de conexão ao banco de dados

// Verifique se o formulário foi enviado via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Capture os dados do formulário
    $id_funcionario = $_POST['id_funcionario'];
    $nome = $_POST['nome'];
    $telefone = $_POST['telefone'];
    $cpf = $_POST['cpf'];
    $sexo = $_POST['sexo'];
    $idade = $_POST['idade'];
    $endereco = $_POST['endereco'];
    $cep = $_POST['cep'];
    $rg = $_POST['rg'];
    $nome_pai = $_POST['nome_pai'];
    $nome_mae = $_POST['nome_mae'];

    // Preparar a consulta SQL para atualizar os dados do funcionário
    $sql = "UPDATE usuarios SET nome = ?, telefone = ?, cpf = ?, sexo = ?, idade = ?, endereco = ?, cep = ?, rg = ?, nome_pai = ?, nome_mae = ? WHERE id = ?";

    // Preparar a declaração
    $stmt = $conn->prepare($sql);

    // Bind dos parâmetros
    $stmt->bind_param('ssssissssss', $nome, $telefone, $cpf, $sexo, $idade, $endereco, $cep, $rg, $nome_pai, $nome_mae, $id_funcionario);

    // Executar a consulta
    if ($stmt->execute()) {
        // Se a atualização for bem-sucedida, redirecionar para uma página de sucesso ou mostrar uma mensagem
        echo 'Dados atualizados com sucesso!';
        echo '<br><a href="index.php">Voltar</a>'; // Link para voltar ao índice ou página principal
    } else {
        echo 'Erro ao atualizar os dados. Tente novamente mais tarde.';
    }

    // Fechar a declaração e a conexão com o banco
    $stmt->close();
    $conn->close();
} else {
    echo 'Método inválido. Apenas POST é permitido.';
}
?>
